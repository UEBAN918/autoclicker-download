const glyph={K:"♔",Q:"♕",R:"♖",B:"♗",N:"♘",P:"♙",k:"♚",q:"♛",r:"♜",b:"♝",n:"♞",p:"♟"};
const pieces=["K","Q","R","B","N","P","k","q","r","b","n","p","."];
const boardEl=document.querySelector("#board"), paletteEl=document.querySelector("#palette");
let board=Array(64).fill(".");
let selected="P";
const initial="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";
function loadPlacement(placement){const rows=placement.split("/");if(rows.length!==8)throw Error("Некорректная расстановка FEN");const next=[];for(const row of rows){let line=[];for(const c of row){if(/[1-8]/.test(c))line.push(...Array(Number(c)).fill("."));else if(glyph[c])line.push(c);else throw Error("Неизвестная фигура в FEN")}if(line.length!==8)throw Error("В каждой строке должно быть 8 клеток");next.push(...line)}board=next;render()}
function placement(){let rows=[];for(let r=0;r<8;r++){let s="",empty=0;for(let c=0;c<8;c++){const p=board[r*8+c];if(p===".")empty++;else{if(empty)s+=empty;empty=0;s+=p}}if(empty)s+=empty;rows.push(s)}return rows.join("/")}
function fen(){return `${placement()} ${document.querySelector("#turn").value} ${document.querySelector("#castling").value||"-"} - 0 1`}
function render(){boardEl.innerHTML="";board.forEach((p,i)=>{const r=Math.floor(i/8),c=i%8,b=document.createElement("button");b.className="square "+((r+c)%2?"dark":"light");b.textContent=glyph[p]||"";b.setAttribute("aria-label",`Клетка ${"abcdefgh"[c]}${8-r}: ${p==="."?"пусто":p}`);b.addEventListener("click",()=>{board[i]=selected;render()});boardEl.appendChild(b)});document.querySelector("#fen").value=fen()}
function renderPalette(){paletteEl.innerHTML="";pieces.forEach(p=>{const b=document.createElement("button");b.textContent=p==="."?"×":glyph[p];b.classList.toggle("selected",selected===p);b.title=p==="."?"Очистить клетку":`Выбрать ${p}`;b.addEventListener("click",()=>{selected=p;renderPalette()});paletteEl.appendChild(b)})}
document.querySelector("#turn").addEventListener("change",()=>document.querySelector("#fen").value=fen());
document.querySelector("#castling").addEventListener("input",()=>document.querySelector("#fen").value=fen());
document.querySelector("#reset").addEventListener("click",()=>{loadPlacement(initial);document.querySelector("#turn").value="w";document.querySelector("#castling").value="KQkq";document.querySelector("#fen").value=fen();});
document.querySelector("#fen").addEventListener("change",e=>{try{const parts=e.target.value.trim().split(/\s+/);loadPlacement(parts[0]);if(parts[1])document.querySelector("#turn").value=parts[1];if(parts[2])document.querySelector("#castling").value=parts[2];document.querySelector("#editStatus").textContent="FEN загружен в редактор."}catch(err){document.querySelector("#editStatus").textContent=err.message}});
document.querySelector("#copyFen").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(fen());document.querySelector("#editStatus").textContent="FEN скопирован."}catch{document.querySelector("#editStatus").textContent="Не удалось скопировать. Выдели FEN вручную."}});
document.querySelector("#imageInput").addEventListener("change",e=>{const file=e.target.files?.[0];if(!file)return;const url=URL.createObjectURL(file);const img=document.querySelector("#preview");img.src=url;img.hidden=false;document.querySelector("#imageStatus").textContent=`Загружено: ${file.name}. Автоматическое распознавание фигур ещё не подключено.`});
loadPlacement(initial);renderPalette();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
